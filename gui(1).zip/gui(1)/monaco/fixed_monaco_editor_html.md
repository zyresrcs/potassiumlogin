<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
	<style type="text/css">
		:root {
			/* replace 'img_url' with your animated image or regular image link */
			--url: url("");
		}

		html,
		body {
			background-color: #222222;
			width: 100%;
			height: 100%;
			margin: 0;
			padding: 0;
			overflow: hidden;
			font-family: Consolas, 'Courier New', monospace;
			color: white;
		}

		.margin:first-child {
			background-image: var(--url);
			background-size: cover;
			background-repeat: no-repeat;
			background-attachment: fixed;
		}

		.lines-content:nth-of-type(1),
		.monaco-editor-background:nth-of-type(1) {
			background-image: var(--url);
			background-size: cover;
			background-repeat: no-repeat;
			background-attachment: fixed;
		}
	
        * { box-sizing: border-box; }
        body { display: flex; flex-direction: column; }
        #tabbar {
            display: flex; align-items: stretch; flex: 0 0 44px; height: 44px;
            min-width: 0; background: #181818; font-family: "Segoe UI", Arial, sans-serif;
            user-select: none; border-bottom: 1px solid #111;
        }
        #tabs {
            display: flex; align-items: stretch; flex: 1 1 auto; min-width: 0;
            overflow-x: auto; overflow-y: hidden; gap: 2px;
            scrollbar-width: none;
        }
        #tabs::-webkit-scrollbar { display: none; }
        .tab {
            display: flex; align-items: center; gap: 9px; flex: 0 0 168px;
            width: 168px; min-width: 120px; padding: 0 10px;
            background: #242424; color: #858585; cursor: pointer;
            border-right: 1px solid #111; font-size: 14px; overflow: hidden;
        }
        .tab.active { background: #1a1a1a; color: #e6e6e6; }
        .tab-mark { color: #bcbcbc; font-size: 17px; line-height: 1; flex: 0 0 auto; }
        .tab-name { flex: 1 1 auto; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
        .tab-close {
            display: flex; align-items: center; justify-content: center; flex: 0 0 20px;
            width: 20px; height: 24px; border-radius: 3px; color: inherit; opacity: .9;
        }
        .tab-close:hover { background: #3a3a3a; color: #fff; }
        #newtab {
            display: flex; align-items: center; justify-content: center; flex: 0 0 44px;
            border: 0; outline: 0; color: #aaa; background: #181818; cursor: pointer;
        }
        #newtab:hover { background: #292929; color: #fff; }
        #container { flex: 1 1 auto; min-height: 0; width: 100%; height: auto !important; }

	</style>
	<meta charset="utf-8" />
	<title></title>
</head>

<body>
    <div id="tabbar">
        <div id="tabs" aria-label="Editor tabs"></div>
        <button id="newtab" type="button" title="New tab" aria-label="New tab">
            <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M7 1v12M1 7h12" stroke="currentColor" stroke-width="1.6" fill="none"/></svg>
        </button>
    </div>
    <div id="container"></div>
	<script src="vs/loader.js"></script>
	<script type="text/javascript">
		require.config({
			paths: {
				'vs': 'vs',
			}
		});

		// API
		var GetText;
		var SetText;
		var SetTheme;
		var SetScroll;
		var ShowErr;
		var Refresh;

		// Enablers
		var SwitchMinimap;
		var SwitchReadonly;
		var SwitchRenderWhitespace;
		var SwitchLinks;
		var SwitchLineHeight;
		var SwitchFontSize;
		var SwitchFolding;
		var SwitchAutoIndent;
		var SwitchFontFamily;
		var SwitchFontLigatures;
		var AddIntellisense;

		// Variables
		var editor;
		var Proposals = [];

		require(['vs/editor/editor.main'], function () {
			function getDependencyProposals() {
				let newProposals = [];
				for (let index = 0; index < Proposals.length; index++) {
					const element = Proposals[index];
					let newElement = {}
					for (const key in element) {
						if (key == "__children__") {
							continue;
						};
						newElement[key] = element[key];
					}
					newProposals.push(newElement)
				}
				return newProposals;
			}

			monaco.editor.defineTheme('net-theme-light', {
				base: 'vs',
				inherit: true,
				rules: [
					{ token: 'global', foreground: '000000' },
					{ token: 'keyword', foreground: 'ff6a00' },
					{ token: 'comment', foreground: '666666' },
					{ token: 'number', foreground: 'ffc600' },
					{ token: 'string', foreground: 'ff8c3a' },
				]
			});

			monaco.editor.defineTheme('net-theme-dark', {
				base: 'vs-dark',
				inherit: true,
				rules: [
					{ token: 'global', foreground: 'FFFFFF', fontStyle: "bold" },
					{ token: 'keyword', foreground: 'ff6a00', fontStyle: "bold" },
					{ token: 'comment', foreground: '666666' },
					{ token: 'number', foreground: 'ffc600' },
					{ token: 'string', foreground: 'ff8c3a' },
				]
			});

			monaco.editor.defineTheme('PDark', {
				base: 'vs-dark',
				inherit: true,
				rules: [
					{ token: '', foreground: '#C3CCDB' },
					{ token: 'variable.language.self', foreground: '#F7768E' },
					{ token: 'variable.parameter.variadic', foreground: '#F7768E' },
					{ token: 'variable.parameter.function', foreground: '#E0AF68' },
					{ token: 'variable.other.constant', foreground: '#FF9E64' },
					{ token: 'variable.property', foreground: '#7DCFFF' },
					{ token: 'variable.object.property', foreground: '#73DACA' },

					{ token: 'keyword', foreground: '#BB9AF7' },
					{ token: 'keyword.local', foreground: '#997BD6', fontStyle: 'italic' },
					{ token: 'keyword.operator', foreground: '#89DDFF' },
					{ token: 'keyword.operator.type.annotation', foreground: '#9ABDF5' },
					{ token: 'keyword.operator.typedef.annotation', foreground: '#89DDFF' },
					{ token: 'keyword.control.export', foreground: '#997BD6', fontStyle: 'italic' },

					{ token: 'operator', foreground: '#89DDFF' },
					{ token: 'operator.type', foreground: '#BB9AF7' },
					{ token: 'operator.special', foreground: '#BB9AF7' },

					{ token: 'entity.name.type.alias', foreground: '#5ab6d6' },
					{ token: 'entity.name.function', foreground: '#7AA2F7' },

					{ token: 'global', foreground: '#7AA2F7' },

					{ token: 'storage.type', foreground: '#BB9AF7' },

					{ token: 'comment', foreground: '#666666', fontStyle: 'italic' },
					{ token: 'comment.highlight.title', foreground: '#89DDFF', fontStyle: 'italic' },
					{ token: 'comment.highlight.name', foreground: '#89DDFF', fontStyle: 'italic' },
					{ token: 'comment.delimiter.modifier', foreground: '#9ABDF5', fontStyle: 'italic' },
					{ token: 'comment.highlight.modifier', foreground: '#7DCFFF', fontStyle: 'italic' },
					{ token: 'comment.highlight.descriptor', foreground: '#F7768E', fontStyle: 'italic' },

					{ token: 'delimiter.longstring', foreground: '#89DDFF' },
					{ token: 'delimiter.bracket', foreground: '#a6afbd' },
					{ token: 'delimiter.array', foreground: '#a6afbd' },
					{ token: 'delimiter.parenthesis', foreground: '#a6afbd' },
					{ token: 'delimiter', foreground: '#a6afbd' },

					{ token: 'string', foreground: '#9ECE6A' },
					{ token: 'longstring', foreground: '#9ECE6A' },
					{ token: 'string.delimeter', foreground: '#89DDFF' },
					{ token: 'string.escape', foreground: '#89DDFF' },

					{ token: 'punctuation.separator.arguments', foreground: '#9ABDF5' },
					{ token: 'punctuation.separator.parameter', foreground: '#89DDFF' },
					{ token: 'punctuation.separator.table', foreground: '#89DDFF' },
					{ token: 'punctuation.definition.block', foreground: '#9ABDF5' },
					{ token: 'punctuation.definition.parameters', foreground: '#9ABDF5' },
					{ token: 'punctuation.definition.typeparameters', foreground: '#89DDFF' },

					{ token: 'constant.language', foreground: '#FF9E64' },
					{ token: 'number', foreground: '#FF9E64' },
					{ token: 'constants', foreground: '#FF9E64' },

					{ token: 'support.function', foreground: '#0DB9D7' },
					{ token: 'support.function.library', foreground: '#0DB9D7' },
					{ token: 'support.type', foreground: '#5ab6d6' },
				],
				colors: {
					'editor.background': '#1A1A1A',

					'editorLineNumber.foreground': '#7A7A7A',
					'editorLineNumber.activeForeground': '#BBBBBB',

					'editorIndentGuide.background': '#1a1a1a',

					'editorSuggestWidget.background': "#181818",
					'editorSuggestWidget.border': "#1a1a1a",
					'editorSuggestWidget.foreground': "#D5D5D5",
					'editorSuggestWidget.selectedBackground': "#404040",
					'editorSuggestWidget.highlightForeground': "#18A0FB",

					'textCodeBlock.background': '#1B1B1B',
				}
			});

			require(['vs/basic-languages/monaco.contribution'], function () {
				monaco.languages.registerCompletionItemProvider('lua', {
					provideCompletionItems: function (model, position) {
						return {
							suggestions: getDependencyProposals(),
						};
					},
					triggerCharacters: ['.', ':', '"'],
				});

				editor = monaco.editor.create(document.getElementById('container'), {
					value: 'print("Hello, world!");',
					language: 'lua',
					theme: "PDark",
					fontSize: "16px",
					fontFamily: "'JetBrains Mono', Consolas, 'Courier New', monospace",
					folding: true,
					dragAndDrop: true,
					links: true,
					minimap: {
						enabled: false,
					},
					showFoldingControls: "always",
					smoothScrolling: true,
					stopRenderingLineAfter: 6500,
					cursorBlinking: "smooth",
					cursorSmoothCaretAnimation: true,
					foldingHighlight: false,
					fontLigatures: true,
					formatOnPaste: true,
					showDeprecated: true,
					scrollBeyondLastLine: false,
					suggest: {
						snippetsPreventQuickSuggestions: false,
					},
					padding: {
						top: 6,
					}
				});
				
				try {
					if (typeof CefSharp !== 'undefined') {
						editor.onKeyDown(function(e) {
							if (!(e.altKey || e.ctrlKey || e.shiftKey || e.metaKey)) {
								if (e.key !== 'Backspace' || editor.getValue() !== '')
								CefSharp.PostMessage('keydown')
							}
						})
					} 
				} catch (err) { }

                // Multiple tabs share one Monaco editor instance; each tab owns a model.
                var tabsElement = document.getElementById('tabs');
                var newTabButton = document.getElementById('newtab');
                var editorTabs = [];
                var activeEditorTab = null;
                var tabId = 0;

                function selectEditorTab(tab) {
                    if (!tab || tab.model.isDisposed()) return;
                    if (activeEditorTab) activeEditorTab.element.classList.remove('active');
                    activeEditorTab = tab;
                    tab.element.classList.add('active');
                    editor.setModel(tab.model);
                    editor.layout();
                    tab.element.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
                    requestAnimationFrame(function () {
                        if (activeEditorTab === tab) {
                            editor.layout();
                            editor.focus();
                        }
                    });
                }

                function createEditorTab(name, initialModel) {
                    var model = initialModel || monaco.editor.createModel('', 'lua');
                    model.updateOptions({ insertSpaces: false });
                    var element = document.createElement('div');
                    element.className = 'tab';
                    element.title = name || 'Untitled Tab';

                    var mark = document.createElement('span');
                    mark.className = 'tab-mark';
                    mark.textContent = '❝';

                    var label = document.createElement('span');
                    label.className = 'tab-name';
                    label.textContent = name || 'Untitled Tab';

                    var close = document.createElement('span');
                    close.className = 'tab-close';
                    close.title = 'Close tab';
                    close.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 2l8 8M10 2L2 10" stroke="currentColor" stroke-width="1.3" fill="none"/></svg>';

                    element.appendChild(mark);
                    element.appendChild(label);
                    element.appendChild(close);
                    var tab = { id: ++tabId, element: element, model: model, label: label, name: label.textContent };
                    element.addEventListener('click', function (event) {
                        if (event.target.closest('.tab-close')) return;
                        selectEditorTab(tab);
                    });
                    close.addEventListener('click', function (event) {
                        event.stopPropagation();
                        closeEditorTab(tab);
                    });
                    element.addEventListener('dblclick', function (event) {
                        if (event.target.closest('.tab-close')) return;
                        var input = document.createElement('input');
                        input.value = tab.name;
                        input.style.cssText = 'width:100%;min-width:0;background:transparent;color:#fff;border:0;outline:0;font:inherit;';
                        label.replaceWith(input);
                        input.focus(); input.select();
                        function finish(save) {
                            if (!input.parentNode) return;
                            if (save && input.value.trim()) tab.name = input.value.trim();
                            label.textContent = tab.name;
                            input.replaceWith(label);
                            element.title = tab.name;
                        }
                        input.addEventListener('keydown', function (e) {
                            e.stopPropagation();
                            if (e.key === 'Enter') finish(true);
                            if (e.key === 'Escape') finish(false);
                        });
                        input.addEventListener('blur', function () { finish(true); });
                        input.addEventListener('click', function (e) { e.stopPropagation(); });
                    });
                    editorTabs.push(tab);
                    tabsElement.appendChild(element);
                    return tab;
                }

                function closeEditorTab(tab) {
                    var index = editorTabs.indexOf(tab);
                    if (index < 0) return;
                    if (editorTabs.length === 1) {
                        tab.model.setValue('');
                        tab.name = 'Untitled Tab';
                        tab.label.textContent = tab.name;
                        selectEditorTab(tab);
                        return;
                    }
                    var wasActive = activeEditorTab === tab;
                    var next = editorTabs[index + 1] || editorTabs[index - 1];
                    editorTabs.splice(index, 1);
                    tab.element.remove();
                    if (wasActive) {
                        activeEditorTab = null;
                        selectEditorTab(next);
                    }
                    tab.model.dispose();
                }

                newTabButton.addEventListener('click', function () {
                    selectEditorTab(createEditorTab('Untitled Tab'));
                });

                // Create the initial tab using the editor's default model and select it properly.
                var initialTab = createEditorTab('Untitled Tab', editor.getModel());
                selectEditorTab(initialTab);
			});

			window.onresize = function () {
				if (editor) {
					editor.layout();
				}
			}

			Cut = function() {
				editor.focus();
				document.execCommand('cut');
			}

			Copy = function() {
				editor.focus();
				document.execCommand('copy');
			}

			Paste = function() {
				editor.focus();
				document.execCommand('paste');
			}

			Undo = function() {
				editor.focus();
				document.execCommand('undo');
			}

			Redo = function() {
				editor.focus();
				document.execCommand('redo');
			}

			Delete = function() {
				editor.focus();
				document.execCommand('delete');
			}

			SelectAll = function() {
				editor.focus();
				document.execCommand('selectAll');
			}

			GetText = function () {
				return String(editor.getValue());
			}

			SetText = function (x) {
				try {
					editor.setValue(JSON.parse(`${String(x)}`));
				} catch (e) {
					editor.setValue(String(x))
				}
			}

			GetProposals = function () {
				return Proposals;
			}


			OnDidChangeContent = function (callback) {
				return editor.onDidChangeModelContent((event) => {
					callback(editor.getValue());
				});
			}

			OnDidChangeCursorPosition = function (callback) {
				return editor.onDidChangeCursorPosition((event) => {
					callback(event.position);
				});
			}

			SetTheme = function (themeName) {
				if (themeName == 'PDark') {
					monaco.editor.setTheme('PDark')
				}
				if (themeName == "Dark") {
					monaco.editor.setTheme("net-theme-dark");
				}
				if (themeName == "Light") {
					monaco.editor.setTheme("net-theme-light");
				}
			}

			SwitchMinimap = function (flag) {
				editor.updateOptions({
					minimap: {
						enabled: flag,
					}
				});
			}

			SwitchReadonly = function (flag) {
				editor.updateOptions({
					readOnly: flag,
				});
			}

			SwitchRenderWhitespace = function (op) {
				editor.updateOptions({
					renderWhitespace: op,
				});
			}

			SwitchLinks = function (flag) {
				editor.updateOptions({
					links: flag,
				});
			}

			SwitchLineHeight = function (num) {
				editor.updateOptions({
					lineHeight: num,
				});
			}

			SwitchFontSize = function (num) {
				editor.updateOptions({
					fontSize: num,
				});
			}

			SwitchFolding = function (flag) {
				editor.updateOptions({
					folding: flag,
				});
			}

			SwitchAutoIndent = function (flag) {
				editor.updateOptions({
					autoIndent: flag,
				});
			}

			SwitchFontFamily = function (name) {
				editor.updateOptions({
					fontFamily: name,
				});
			}

			SwitchFontLigatures = function (flag) {
				editor.updateOptions({
					fontLigatures: flag,
				});
			}

			ShowErr = function (line, column, endline, endcolumn, errMessage) {
				editor.revealPositionInCenter({ lineNumber: line, column: column });
				editor.deltaDecorations([], [
					{
						range: new monaco.Range(line, column, endline, endcolumn),
						options: {
							inlineClassName: 'squiggly-error',
							hoverMessage: {
								value: errMessage,
							}
						},
					},
				]);
			}

			AddSnippet = function (kindName, snippetName, data) {
				let snippet = {
					insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
					kind: monaco.languages.CompletionItemKind[kindName],
				};
				for (const key in data) {
					let value = data[key];
					if (key == "insertText" && typeof value == "object") {
						value = value.join("\n");
					};
					snippet[key] = value;
				}
				if (!snippet.label) {
					snippet.label = snippetName
				}
				if (!snippet.insertText) {
					snippet.insertText = snippetName
				}
				Proposals.push(snippet);
			}

			AddRawSnippet = function (data) {
				Proposals.push(data);
			}

			SetScroll = function (line) {
				editor.revealLineInCenter({ lineNumber: line });
			}

			Refresh = function () {
				var text = GetText();
				SetText("");
				editor.trigger('keyboard', 'type', { text: text });
			}

		});
	</script>
</body>

</html>